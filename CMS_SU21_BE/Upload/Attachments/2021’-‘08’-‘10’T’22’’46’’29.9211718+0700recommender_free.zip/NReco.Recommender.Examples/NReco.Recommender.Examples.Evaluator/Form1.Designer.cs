﻿namespace NReco.Recommender.Examples.Evaluator
{
    partial class EvaluatorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.textBox_filePath = new System.Windows.Forms.TextBox();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.radioButton_CityBlockSimilarity = new System.Windows.Forms.RadioButton();
			this.radioButton_UncenteredCosineSimilarity = new System.Windows.Forms.RadioButton();
			this.radioButton_TanimotoCoefficientSimilarity = new System.Windows.Forms.RadioButton();
			this.radioButton_SpearmanCorrelationSimilarity = new System.Windows.Forms.RadioButton();
			this.radioButton_PearsonCorrelationSimilarity = new System.Windows.Forms.RadioButton();
			this.radioButton_LogLikelihoodSimilarity = new System.Windows.Forms.RadioButton();
			this.radioButton_EuclideanDistanceSimilarity = new System.Windows.Forms.RadioButton();
			this.groupBox_Neighborhood = new System.Windows.Forms.GroupBox();
			this.textBox_threshold = new System.Windows.Forms.TextBox();
			this.radioButton_ThresholdUserNeighborhood = new System.Windows.Forms.RadioButton();
			this.textBox_NearestNUserNeighborhood = new System.Windows.Forms.TextBox();
			this.radioButton_NearestNUserNeighborhood = new System.Windows.Forms.RadioButton();
			this.groupBox4 = new System.Windows.Forms.GroupBox();
			this.textBox_irstats_eval = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.textBox_irstats_at = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.textBox_avgabsdiff_eval = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox_avgabsdiff_training = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.checkBox_IRStats = new System.Windows.Forms.CheckBox();
			this.checkBox_AverageAbsoluteDifference = new System.Windows.Forms.CheckBox();
			this.textBox_results = new System.Windows.Forms.TextBox();
			this.button_evaluate = new System.Windows.Forms.Button();
			this.groupBox5 = new System.Windows.Forms.GroupBox();
			this.radioButton_itemBased = new System.Windows.Forms.RadioButton();
			this.radioButton_userBased = new System.Windows.Forms.RadioButton();
			this.groupBox_CandidateItemsStrategy = new System.Windows.Forms.GroupBox();
			this.radioButton_AllUnknownItems = new System.Windows.Forms.RadioButton();
			this.radioButton_AllSimilarItems = new System.Windows.Forms.RadioButton();
			this.radioButton_PreferredItemsNeighborhood = new System.Windows.Forms.RadioButton();
			this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
			this.buttonBrowseFile = new System.Windows.Forms.Button();
			this.label6 = new System.Windows.Forms.Label();
			this.groupBox1.SuspendLayout();
			this.groupBox2.SuspendLayout();
			this.groupBox_Neighborhood.SuspendLayout();
			this.groupBox4.SuspendLayout();
			this.groupBox5.SuspendLayout();
			this.groupBox_CandidateItemsStrategy.SuspendLayout();
			this.SuspendLayout();
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.buttonBrowseFile);
			this.groupBox1.Controls.Add(this.label1);
			this.groupBox1.Controls.Add(this.textBox_filePath);
			this.groupBox1.Location = new System.Drawing.Point(3, 0);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(726, 45);
			this.groupBox1.TabIndex = 3;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "FileDataModel";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(7, 20);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(23, 13);
			this.label1.TabIndex = 1;
			this.label1.Text = "File";
			// 
			// textBox_filePath
			// 
			this.textBox_filePath.Location = new System.Drawing.Point(37, 17);
			this.textBox_filePath.Name = "textBox_filePath";
			this.textBox_filePath.Size = new System.Drawing.Size(402, 20);
			this.textBox_filePath.TabIndex = 0;
			this.textBox_filePath.Text = "ratings.csv";
			// 
			// groupBox2
			// 
			this.groupBox2.Controls.Add(this.radioButton_CityBlockSimilarity);
			this.groupBox2.Controls.Add(this.radioButton_UncenteredCosineSimilarity);
			this.groupBox2.Controls.Add(this.radioButton_TanimotoCoefficientSimilarity);
			this.groupBox2.Controls.Add(this.radioButton_SpearmanCorrelationSimilarity);
			this.groupBox2.Controls.Add(this.radioButton_PearsonCorrelationSimilarity);
			this.groupBox2.Controls.Add(this.radioButton_LogLikelihoodSimilarity);
			this.groupBox2.Controls.Add(this.radioButton_EuclideanDistanceSimilarity);
			this.groupBox2.Location = new System.Drawing.Point(4, 103);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(281, 195);
			this.groupBox2.TabIndex = 4;
			this.groupBox2.TabStop = false;
			this.groupBox2.Text = "Similarity";
			// 
			// radioButton_CityBlockSimilarity
			// 
			this.radioButton_CityBlockSimilarity.AutoSize = true;
			this.radioButton_CityBlockSimilarity.Location = new System.Drawing.Point(7, 163);
			this.radioButton_CityBlockSimilarity.Name = "radioButton_CityBlockSimilarity";
			this.radioButton_CityBlockSimilarity.Size = new System.Drawing.Size(109, 17);
			this.radioButton_CityBlockSimilarity.TabIndex = 6;
			this.radioButton_CityBlockSimilarity.Text = "CityBlockSimilarity";
			this.radioButton_CityBlockSimilarity.UseVisualStyleBackColor = true;
			// 
			// radioButton_UncenteredCosineSimilarity
			// 
			this.radioButton_UncenteredCosineSimilarity.AutoSize = true;
			this.radioButton_UncenteredCosineSimilarity.Location = new System.Drawing.Point(7, 139);
			this.radioButton_UncenteredCosineSimilarity.Name = "radioButton_UncenteredCosineSimilarity";
			this.radioButton_UncenteredCosineSimilarity.Size = new System.Drawing.Size(153, 17);
			this.radioButton_UncenteredCosineSimilarity.TabIndex = 5;
			this.radioButton_UncenteredCosineSimilarity.Text = "UncenteredCosineSimilarity";
			this.radioButton_UncenteredCosineSimilarity.UseVisualStyleBackColor = true;
			// 
			// radioButton_TanimotoCoefficientSimilarity
			// 
			this.radioButton_TanimotoCoefficientSimilarity.AutoSize = true;
			this.radioButton_TanimotoCoefficientSimilarity.Location = new System.Drawing.Point(7, 115);
			this.radioButton_TanimotoCoefficientSimilarity.Name = "radioButton_TanimotoCoefficientSimilarity";
			this.radioButton_TanimotoCoefficientSimilarity.Size = new System.Drawing.Size(159, 17);
			this.radioButton_TanimotoCoefficientSimilarity.TabIndex = 4;
			this.radioButton_TanimotoCoefficientSimilarity.Text = "TanimotoCoefficientSimilarity";
			this.radioButton_TanimotoCoefficientSimilarity.UseVisualStyleBackColor = true;
			// 
			// radioButton_SpearmanCorrelationSimilarity
			// 
			this.radioButton_SpearmanCorrelationSimilarity.AutoSize = true;
			this.radioButton_SpearmanCorrelationSimilarity.Location = new System.Drawing.Point(7, 91);
			this.radioButton_SpearmanCorrelationSimilarity.Name = "radioButton_SpearmanCorrelationSimilarity";
			this.radioButton_SpearmanCorrelationSimilarity.Size = new System.Drawing.Size(163, 17);
			this.radioButton_SpearmanCorrelationSimilarity.TabIndex = 3;
			this.radioButton_SpearmanCorrelationSimilarity.Text = "SpearmanCorrelationSimilarity";
			this.radioButton_SpearmanCorrelationSimilarity.UseVisualStyleBackColor = true;
			// 
			// radioButton_PearsonCorrelationSimilarity
			// 
			this.radioButton_PearsonCorrelationSimilarity.AutoSize = true;
			this.radioButton_PearsonCorrelationSimilarity.Location = new System.Drawing.Point(7, 68);
			this.radioButton_PearsonCorrelationSimilarity.Name = "radioButton_PearsonCorrelationSimilarity";
			this.radioButton_PearsonCorrelationSimilarity.Size = new System.Drawing.Size(154, 17);
			this.radioButton_PearsonCorrelationSimilarity.TabIndex = 2;
			this.radioButton_PearsonCorrelationSimilarity.Text = "PearsonCorrelationSimilarity";
			this.radioButton_PearsonCorrelationSimilarity.UseVisualStyleBackColor = true;
			// 
			// radioButton_LogLikelihoodSimilarity
			// 
			this.radioButton_LogLikelihoodSimilarity.AutoSize = true;
			this.radioButton_LogLikelihoodSimilarity.Checked = true;
			this.radioButton_LogLikelihoodSimilarity.Location = new System.Drawing.Point(7, 44);
			this.radioButton_LogLikelihoodSimilarity.Name = "radioButton_LogLikelihoodSimilarity";
			this.radioButton_LogLikelihoodSimilarity.Size = new System.Drawing.Size(131, 17);
			this.radioButton_LogLikelihoodSimilarity.TabIndex = 1;
			this.radioButton_LogLikelihoodSimilarity.TabStop = true;
			this.radioButton_LogLikelihoodSimilarity.Text = "LogLikelihoodSimilarity";
			this.radioButton_LogLikelihoodSimilarity.UseVisualStyleBackColor = true;
			// 
			// radioButton_EuclideanDistanceSimilarity
			// 
			this.radioButton_EuclideanDistanceSimilarity.AutoSize = true;
			this.radioButton_EuclideanDistanceSimilarity.Location = new System.Drawing.Point(7, 20);
			this.radioButton_EuclideanDistanceSimilarity.Name = "radioButton_EuclideanDistanceSimilarity";
			this.radioButton_EuclideanDistanceSimilarity.Size = new System.Drawing.Size(154, 17);
			this.radioButton_EuclideanDistanceSimilarity.TabIndex = 0;
			this.radioButton_EuclideanDistanceSimilarity.Text = "EuclideanDistanceSimilarity";
			this.radioButton_EuclideanDistanceSimilarity.UseVisualStyleBackColor = true;
			// 
			// groupBox_Neighborhood
			// 
			this.groupBox_Neighborhood.Controls.Add(this.textBox_threshold);
			this.groupBox_Neighborhood.Controls.Add(this.radioButton_ThresholdUserNeighborhood);
			this.groupBox_Neighborhood.Controls.Add(this.textBox_NearestNUserNeighborhood);
			this.groupBox_Neighborhood.Controls.Add(this.radioButton_NearestNUserNeighborhood);
			this.groupBox_Neighborhood.Location = new System.Drawing.Point(291, 103);
			this.groupBox_Neighborhood.Name = "groupBox_Neighborhood";
			this.groupBox_Neighborhood.Size = new System.Drawing.Size(438, 72);
			this.groupBox_Neighborhood.TabIndex = 5;
			this.groupBox_Neighborhood.TabStop = false;
			this.groupBox_Neighborhood.Text = "Neighborhood";
			// 
			// textBox_threshold
			// 
			this.textBox_threshold.Location = new System.Drawing.Point(171, 41);
			this.textBox_threshold.Name = "textBox_threshold";
			this.textBox_threshold.Size = new System.Drawing.Size(100, 20);
			this.textBox_threshold.TabIndex = 3;
			this.textBox_threshold.Text = "0.7";
			// 
			// radioButton_ThresholdUserNeighborhood
			// 
			this.radioButton_ThresholdUserNeighborhood.AutoSize = true;
			this.radioButton_ThresholdUserNeighborhood.Location = new System.Drawing.Point(6, 43);
			this.radioButton_ThresholdUserNeighborhood.Name = "radioButton_ThresholdUserNeighborhood";
			this.radioButton_ThresholdUserNeighborhood.Size = new System.Drawing.Size(161, 17);
			this.radioButton_ThresholdUserNeighborhood.TabIndex = 2;
			this.radioButton_ThresholdUserNeighborhood.TabStop = true;
			this.radioButton_ThresholdUserNeighborhood.Text = "ThresholdUserNeighborhood";
			this.radioButton_ThresholdUserNeighborhood.UseVisualStyleBackColor = true;
			// 
			// textBox_NearestNUserNeighborhood
			// 
			this.textBox_NearestNUserNeighborhood.Location = new System.Drawing.Point(171, 16);
			this.textBox_NearestNUserNeighborhood.Name = "textBox_NearestNUserNeighborhood";
			this.textBox_NearestNUserNeighborhood.Size = new System.Drawing.Size(100, 20);
			this.textBox_NearestNUserNeighborhood.TabIndex = 1;
			this.textBox_NearestNUserNeighborhood.Text = "10";
			// 
			// radioButton_NearestNUserNeighborhood
			// 
			this.radioButton_NearestNUserNeighborhood.AutoSize = true;
			this.radioButton_NearestNUserNeighborhood.Checked = true;
			this.radioButton_NearestNUserNeighborhood.Location = new System.Drawing.Point(6, 19);
			this.radioButton_NearestNUserNeighborhood.Name = "radioButton_NearestNUserNeighborhood";
			this.radioButton_NearestNUserNeighborhood.Size = new System.Drawing.Size(159, 17);
			this.radioButton_NearestNUserNeighborhood.TabIndex = 0;
			this.radioButton_NearestNUserNeighborhood.TabStop = true;
			this.radioButton_NearestNUserNeighborhood.Text = "NearestNUserNeighborhood";
			this.radioButton_NearestNUserNeighborhood.UseVisualStyleBackColor = true;
			// 
			// groupBox4
			// 
			this.groupBox4.Controls.Add(this.label6);
			this.groupBox4.Controls.Add(this.textBox_irstats_eval);
			this.groupBox4.Controls.Add(this.label5);
			this.groupBox4.Controls.Add(this.textBox_irstats_at);
			this.groupBox4.Controls.Add(this.label4);
			this.groupBox4.Controls.Add(this.textBox_avgabsdiff_eval);
			this.groupBox4.Controls.Add(this.label3);
			this.groupBox4.Controls.Add(this.textBox_avgabsdiff_training);
			this.groupBox4.Controls.Add(this.label2);
			this.groupBox4.Controls.Add(this.checkBox_IRStats);
			this.groupBox4.Controls.Add(this.checkBox_AverageAbsoluteDifference);
			this.groupBox4.Controls.Add(this.textBox_results);
			this.groupBox4.Location = new System.Drawing.Point(4, 304);
			this.groupBox4.Name = "groupBox4";
			this.groupBox4.Size = new System.Drawing.Size(725, 272);
			this.groupBox4.TabIndex = 6;
			this.groupBox4.TabStop = false;
			this.groupBox4.Text = "Evaluation";
			// 
			// textBox_irstats_eval
			// 
			this.textBox_irstats_eval.Location = new System.Drawing.Point(318, 44);
			this.textBox_irstats_eval.Name = "textBox_irstats_eval";
			this.textBox_irstats_eval.Size = new System.Drawing.Size(47, 20);
			this.textBox_irstats_eval.TabIndex = 10;
			this.textBox_irstats_eval.Text = "0.1";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(291, 45);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(30, 13);
			this.label5.TabIndex = 9;
			this.label5.Text = "eval:";
			// 
			// textBox_irstats_at
			// 
			this.textBox_irstats_at.Location = new System.Drawing.Point(230, 43);
			this.textBox_irstats_at.Name = "textBox_irstats_at";
			this.textBox_irstats_at.Size = new System.Drawing.Size(45, 20);
			this.textBox_irstats_at.TabIndex = 8;
			this.textBox_irstats_at.Text = "2";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(151, 44);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(82, 13);
			this.label4.TabIndex = 7;
			this.label4.Text = "precision at top:";
			// 
			// textBox_avgabsdiff_eval
			// 
			this.textBox_avgabsdiff_eval.Location = new System.Drawing.Point(318, 16);
			this.textBox_avgabsdiff_eval.Name = "textBox_avgabsdiff_eval";
			this.textBox_avgabsdiff_eval.Size = new System.Drawing.Size(47, 20);
			this.textBox_avgabsdiff_eval.TabIndex = 6;
			this.textBox_avgabsdiff_eval.Text = "1.0";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(291, 20);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(30, 13);
			this.label3.TabIndex = 5;
			this.label3.Text = "eval:";
			// 
			// textBox_avgabsdiff_training
			// 
			this.textBox_avgabsdiff_training.Location = new System.Drawing.Point(230, 16);
			this.textBox_avgabsdiff_training.Name = "textBox_avgabsdiff_training";
			this.textBox_avgabsdiff_training.Size = new System.Drawing.Size(45, 20);
			this.textBox_avgabsdiff_training.TabIndex = 4;
			this.textBox_avgabsdiff_training.Text = "0.7";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(189, 19);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(44, 13);
			this.label2.TabIndex = 3;
			this.label2.Text = "training:";
			// 
			// checkBox_IRStats
			// 
			this.checkBox_IRStats.AutoSize = true;
			this.checkBox_IRStats.Location = new System.Drawing.Point(7, 43);
			this.checkBox_IRStats.Name = "checkBox_IRStats";
			this.checkBox_IRStats.Size = new System.Drawing.Size(61, 17);
			this.checkBox_IRStats.TabIndex = 2;
			this.checkBox_IRStats.Text = "IRStats";
			this.checkBox_IRStats.UseVisualStyleBackColor = true;
			// 
			// checkBox_AverageAbsoluteDifference
			// 
			this.checkBox_AverageAbsoluteDifference.AutoSize = true;
			this.checkBox_AverageAbsoluteDifference.Checked = true;
			this.checkBox_AverageAbsoluteDifference.CheckState = System.Windows.Forms.CheckState.Checked;
			this.checkBox_AverageAbsoluteDifference.Location = new System.Drawing.Point(7, 19);
			this.checkBox_AverageAbsoluteDifference.Name = "checkBox_AverageAbsoluteDifference";
			this.checkBox_AverageAbsoluteDifference.Size = new System.Drawing.Size(156, 17);
			this.checkBox_AverageAbsoluteDifference.TabIndex = 1;
			this.checkBox_AverageAbsoluteDifference.Text = "AverageAbsoluteDifference";
			this.checkBox_AverageAbsoluteDifference.UseVisualStyleBackColor = true;
			// 
			// textBox_results
			// 
			this.textBox_results.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.textBox_results.Location = new System.Drawing.Point(7, 67);
			this.textBox_results.Multiline = true;
			this.textBox_results.Name = "textBox_results";
			this.textBox_results.ReadOnly = true;
			this.textBox_results.Size = new System.Drawing.Size(712, 199);
			this.textBox_results.TabIndex = 0;
			// 
			// button_evaluate
			// 
			this.button_evaluate.Location = new System.Drawing.Point(3, 582);
			this.button_evaluate.Name = "button_evaluate";
			this.button_evaluate.Size = new System.Drawing.Size(720, 33);
			this.button_evaluate.TabIndex = 7;
			this.button_evaluate.Text = "EVALUATE";
			this.button_evaluate.UseVisualStyleBackColor = true;
			this.button_evaluate.Click += new System.EventHandler(this.button_evaluate_Click);
			// 
			// groupBox5
			// 
			this.groupBox5.Controls.Add(this.radioButton_itemBased);
			this.groupBox5.Controls.Add(this.radioButton_userBased);
			this.groupBox5.Location = new System.Drawing.Point(3, 51);
			this.groupBox5.Name = "groupBox5";
			this.groupBox5.Size = new System.Drawing.Size(726, 46);
			this.groupBox5.TabIndex = 8;
			this.groupBox5.TabStop = false;
			this.groupBox5.Text = "Recommender";
			this.groupBox5.Enter += new System.EventHandler(this.groupBox5_Enter);
			// 
			// radioButton_itemBased
			// 
			this.radioButton_itemBased.AutoSize = true;
			this.radioButton_itemBased.Location = new System.Drawing.Point(217, 20);
			this.radioButton_itemBased.Name = "radioButton_itemBased";
			this.radioButton_itemBased.Size = new System.Drawing.Size(181, 17);
			this.radioButton_itemBased.TabIndex = 1;
			this.radioButton_itemBased.Text = "GenericItemBasedRecommender";
			this.radioButton_itemBased.UseVisualStyleBackColor = true;
			this.radioButton_itemBased.CheckedChanged += new System.EventHandler(this.radioButton_itemBased_CheckedChanged);
			// 
			// radioButton_userBased
			// 
			this.radioButton_userBased.AutoSize = true;
			this.radioButton_userBased.Checked = true;
			this.radioButton_userBased.Location = new System.Drawing.Point(6, 20);
			this.radioButton_userBased.Name = "radioButton_userBased";
			this.radioButton_userBased.Size = new System.Drawing.Size(183, 17);
			this.radioButton_userBased.TabIndex = 0;
			this.radioButton_userBased.TabStop = true;
			this.radioButton_userBased.Text = "GenericUserBasedRecommender";
			this.radioButton_userBased.UseVisualStyleBackColor = true;
			this.radioButton_userBased.CheckedChanged += new System.EventHandler(this.radioButton_userBased_CheckedChanged);
			// 
			// groupBox_CandidateItemsStrategy
			// 
			this.groupBox_CandidateItemsStrategy.Controls.Add(this.radioButton_AllUnknownItems);
			this.groupBox_CandidateItemsStrategy.Controls.Add(this.radioButton_AllSimilarItems);
			this.groupBox_CandidateItemsStrategy.Controls.Add(this.radioButton_PreferredItemsNeighborhood);
			this.groupBox_CandidateItemsStrategy.Location = new System.Drawing.Point(291, 181);
			this.groupBox_CandidateItemsStrategy.Name = "groupBox_CandidateItemsStrategy";
			this.groupBox_CandidateItemsStrategy.Size = new System.Drawing.Size(438, 117);
			this.groupBox_CandidateItemsStrategy.TabIndex = 9;
			this.groupBox_CandidateItemsStrategy.TabStop = false;
			this.groupBox_CandidateItemsStrategy.Text = "Candidate Items Strategy";
			// 
			// radioButton_AllUnknownItems
			// 
			this.radioButton_AllUnknownItems.AutoSize = true;
			this.radioButton_AllUnknownItems.Location = new System.Drawing.Point(6, 68);
			this.radioButton_AllUnknownItems.Name = "radioButton_AllUnknownItems";
			this.radioButton_AllUnknownItems.Size = new System.Drawing.Size(107, 17);
			this.radioButton_AllUnknownItems.TabIndex = 2;
			this.radioButton_AllUnknownItems.TabStop = true;
			this.radioButton_AllUnknownItems.Text = "AllUnknownItems";
			this.radioButton_AllUnknownItems.UseVisualStyleBackColor = true;
			// 
			// radioButton_AllSimilarItems
			// 
			this.radioButton_AllSimilarItems.AutoSize = true;
			this.radioButton_AllSimilarItems.Location = new System.Drawing.Point(6, 44);
			this.radioButton_AllSimilarItems.Name = "radioButton_AllSimilarItems";
			this.radioButton_AllSimilarItems.Size = new System.Drawing.Size(91, 17);
			this.radioButton_AllSimilarItems.TabIndex = 1;
			this.radioButton_AllSimilarItems.TabStop = true;
			this.radioButton_AllSimilarItems.Text = "AllSimilarItems";
			this.radioButton_AllSimilarItems.UseVisualStyleBackColor = true;
			// 
			// radioButton_PreferredItemsNeighborhood
			// 
			this.radioButton_PreferredItemsNeighborhood.AutoSize = true;
			this.radioButton_PreferredItemsNeighborhood.Checked = true;
			this.radioButton_PreferredItemsNeighborhood.Location = new System.Drawing.Point(6, 20);
			this.radioButton_PreferredItemsNeighborhood.Name = "radioButton_PreferredItemsNeighborhood";
			this.radioButton_PreferredItemsNeighborhood.Size = new System.Drawing.Size(160, 17);
			this.radioButton_PreferredItemsNeighborhood.TabIndex = 0;
			this.radioButton_PreferredItemsNeighborhood.TabStop = true;
			this.radioButton_PreferredItemsNeighborhood.Text = "PreferredItemsNeighborhood";
			this.radioButton_PreferredItemsNeighborhood.UseVisualStyleBackColor = true;
			// 
			// buttonBrowseFile
			// 
			this.buttonBrowseFile.Location = new System.Drawing.Point(445, 17);
			this.buttonBrowseFile.Name = "buttonBrowseFile";
			this.buttonBrowseFile.Size = new System.Drawing.Size(114, 20);
			this.buttonBrowseFile.TabIndex = 2;
			this.buttonBrowseFile.Text = "Browse...";
			this.buttonBrowseFile.UseVisualStyleBackColor = true;
			this.buttonBrowseFile.Click += new System.EventHandler(this.buttonBrowseFile_Click);
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(371, 50);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(326, 13);
			this.label6.TabIndex = 11;
			this.label6.Text = "Warning: calculation of precision/recall is VERY CPU intensive task";
			this.label6.Click += new System.EventHandler(this.label6_Click);
			// 
			// EvaluatorForm
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(731, 618);
			this.Controls.Add(this.groupBox_CandidateItemsStrategy);
			this.Controls.Add(this.groupBox5);
			this.Controls.Add(this.button_evaluate);
			this.Controls.Add(this.groupBox4);
			this.Controls.Add(this.groupBox_Neighborhood);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Name = "EvaluatorForm";
			this.Text = "NReco.Recommender Evaluator";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.groupBox2.ResumeLayout(false);
			this.groupBox2.PerformLayout();
			this.groupBox_Neighborhood.ResumeLayout(false);
			this.groupBox_Neighborhood.PerformLayout();
			this.groupBox4.ResumeLayout(false);
			this.groupBox4.PerformLayout();
			this.groupBox5.ResumeLayout(false);
			this.groupBox5.PerformLayout();
			this.groupBox_CandidateItemsStrategy.ResumeLayout(false);
			this.groupBox_CandidateItemsStrategy.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion

		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox textBox_filePath;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.GroupBox groupBox_Neighborhood;
		private System.Windows.Forms.RadioButton radioButton_EuclideanDistanceSimilarity;
		private System.Windows.Forms.RadioButton radioButton_LogLikelihoodSimilarity;
		private System.Windows.Forms.RadioButton radioButton_PearsonCorrelationSimilarity;
		private System.Windows.Forms.RadioButton radioButton_SpearmanCorrelationSimilarity;
		private System.Windows.Forms.RadioButton radioButton_TanimotoCoefficientSimilarity;
		private System.Windows.Forms.RadioButton radioButton_UncenteredCosineSimilarity;
		private System.Windows.Forms.RadioButton radioButton_CityBlockSimilarity;
		private System.Windows.Forms.RadioButton radioButton_NearestNUserNeighborhood;
		private System.Windows.Forms.RadioButton radioButton_ThresholdUserNeighborhood;
		private System.Windows.Forms.TextBox textBox_NearestNUserNeighborhood;
		private System.Windows.Forms.TextBox textBox_threshold;
		private System.Windows.Forms.GroupBox groupBox4;
		private System.Windows.Forms.TextBox textBox_results;
		private System.Windows.Forms.Button button_evaluate;
		private System.Windows.Forms.CheckBox checkBox_AverageAbsoluteDifference;
		private System.Windows.Forms.CheckBox checkBox_IRStats;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox textBox_avgabsdiff_training;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox textBox_avgabsdiff_eval;
		private System.Windows.Forms.TextBox textBox_irstats_eval;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.TextBox textBox_irstats_at;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.GroupBox groupBox5;
		private System.Windows.Forms.RadioButton radioButton_userBased;
		private System.Windows.Forms.RadioButton radioButton_itemBased;
		private System.Windows.Forms.GroupBox groupBox_CandidateItemsStrategy;
		private System.Windows.Forms.RadioButton radioButton_PreferredItemsNeighborhood;
		private System.Windows.Forms.RadioButton radioButton_AllSimilarItems;
		private System.Windows.Forms.RadioButton radioButton_AllUnknownItems;
		private System.Windows.Forms.Button buttonBrowseFile;
		private System.Windows.Forms.OpenFileDialog openFileDialog1;
		private System.Windows.Forms.Label label6;
    }
}

