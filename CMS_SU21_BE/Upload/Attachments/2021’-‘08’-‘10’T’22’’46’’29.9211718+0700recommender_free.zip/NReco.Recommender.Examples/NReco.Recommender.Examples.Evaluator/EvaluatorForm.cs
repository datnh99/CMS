﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Globalization;
using System.IO;

using NReco.CF.Taste.Similarity;
using NReco.CF.Taste.Neighborhood;
using NReco.CF.Taste.Recommender;
using NReco.CF.Taste.Model;
using NReco.CF.Taste.Eval;

using NReco.CF.Taste.Impl.Neighborhood;
using NReco.CF.Taste.Impl.Recommender;
using NReco.CF.Taste.Impl.Similarity;
using NReco.CF.Taste.Impl.Model;
using NReco.CF.Taste.Impl.Eval;

using NReco.CF.Taste.Impl.Model.File;

namespace NReco.Recommender.Examples.Evaluator
{
    public partial class EvaluatorForm : Form
    {
        public EvaluatorForm()
        {
            InitializeComponent();
			OnRecommenderChanged();
        }

		IDataModel GetDataModel() {
			var filePath = textBox_filePath.Text;
			if (!File.Exists(filePath))
				throw new FileNotFoundException(String.Format("File not found: {0}", filePath));
			return new FileDataModel(filePath);
		}

		private void button_evaluate_Click(object sender, EventArgs e) {
			var evalTask = new Task(EvaluateRecommender);
			evalTask.Start();
		}

		IRecommenderBuilder GetRecommender(IDataModel model) {
			if (radioButton_userBased.Checked)
				return new UserBasedRecommenderBuilder(this);
			if (radioButton_itemBased.Checked)
				return new ItemBasedRecommenderBuilder(this);
			throw new NotImplementedException();
		}

		void AddToResult(string text, bool clear = false) {
			textBox_results.Invoke( (Action)( () => {
				if (clear)
					textBox_results.Text = String.Empty;
				textBox_results.Text += text;
			}) );
		}

		protected void EvaluateRecommender() {
			try {
				button_evaluate.Invoke( (Action) (() => { button_evaluate.Enabled = false; }) );

				var model = GetDataModel();
				var recommenderBuilder = GetRecommender(model);

				AddToResult("", true);

				if (checkBox_AverageAbsoluteDifference.Checked) {
					AddToResult("Evaluating average absolute difference...\r\n(this may take several minutes)\r\n");

					IRecommenderEvaluator evaluator = new AverageAbsoluteDifferenceRecommenderEvaluator();
					var avgAbsDiff = evaluator.Evaluate(recommenderBuilder, null, model,
							Convert.ToDouble(textBox_avgabsdiff_training.Text, CultureInfo.InvariantCulture),
							Convert.ToDouble(textBox_avgabsdiff_eval.Text, CultureInfo.InvariantCulture));
					
					AddToResult( String.Format("Average absolute difference: {0:0.####}\r\n", avgAbsDiff) );
				}

				if (checkBox_IRStats.Checked) {
					AddToResult( "Evaluating precision and recall...\r\n(this may take several minutes)\r\n" );

					var irStatsEvaluator = new GenericRecommenderIRStatsEvaluator();
					var irStats = irStatsEvaluator.Evaluate(recommenderBuilder, null, model, null,
							Convert.ToInt32(textBox_irstats_at.Text),
							GenericRecommenderIRStatsEvaluator.CHOOSE_THRESHOLD,
							Convert.ToDouble(textBox_irstats_eval.Text, CultureInfo.InvariantCulture)
						);
					
					AddToResult(String.Format("Precision: {0:0.####}\r\n", irStats.GetPrecision()) );
					AddToResult(String.Format("Recall: {0:0.####}\r\n", irStats.GetRecall()) );
					AddToResult(String.Format("F1: {0:0.####}\r\n", irStats.GetF1Measure()) );
				}
			} catch (Exception ex) {
				AddToResult( String.Format("ERROR: {0}", ex.ToString()) );
			} finally {
				button_evaluate.Invoke( (Action)( () => {
					button_evaluate.Enabled = true;
				}) );
			}
		}

		public ICandidateItemsStrategy GetCandidateItemsStrategy(IDataModel dataModel, IItemSimilarity similarity) {
			if (radioButton_PreferredItemsNeighborhood.Checked) {
				return new PreferredItemsNeighborhoodCandidateItemsStrategy();
			}
			if (radioButton_AllSimilarItems.Checked) {
				return new AllSimilarItemsCandidateItemsStrategy(similarity);
			}
			if (radioButton_AllUnknownItems.Checked) {
				return new AllUnknownItemsCandidateItemsStrategy();
			}
			throw new NotSupportedException();
		}

		public IUserSimilarity GetUserSimilarity(IDataModel dataModel) {
			if (radioButton_CityBlockSimilarity.Checked)
				return new CityBlockSimilarity(dataModel);
			if (radioButton_EuclideanDistanceSimilarity.Checked)
				return new EuclideanDistanceSimilarity(dataModel);
			if (radioButton_LogLikelihoodSimilarity.Checked)
				return new LogLikelihoodSimilarity(dataModel);
			if (radioButton_PearsonCorrelationSimilarity.Checked)
				return new PearsonCorrelationSimilarity(dataModel);
			if (radioButton_SpearmanCorrelationSimilarity.Checked)
				return new SpearmanCorrelationSimilarity(dataModel);
			if (radioButton_TanimotoCoefficientSimilarity.Checked)
				return new TanimotoCoefficientSimilarity(dataModel);
			if (radioButton_UncenteredCosineSimilarity.Checked)
				return new UncenteredCosineSimilarity(dataModel);
			throw new NotSupportedException();
		}

		public IItemSimilarity GetItemSimilarity(IDataModel dataModel) {
			if (radioButton_CityBlockSimilarity.Checked)
				return new CityBlockSimilarity(dataModel);
			if (radioButton_EuclideanDistanceSimilarity.Checked)
				return new EuclideanDistanceSimilarity(dataModel);
			if (radioButton_LogLikelihoodSimilarity.Checked)
				return new LogLikelihoodSimilarity(dataModel);
			if (radioButton_PearsonCorrelationSimilarity.Checked)
				return new PearsonCorrelationSimilarity(dataModel);
			if (radioButton_TanimotoCoefficientSimilarity.Checked)
				return new TanimotoCoefficientSimilarity(dataModel);
			if (radioButton_UncenteredCosineSimilarity.Checked)
				return new UncenteredCosineSimilarity(dataModel);
			throw new NotSupportedException();
		}

		public IUserNeighborhood GetNeighborhood(IDataModel dataModel, IUserSimilarity similarity) {
			if (radioButton_NearestNUserNeighborhood.Checked) {
				return new NearestNUserNeighborhood(Convert.ToInt32(textBox_NearestNUserNeighborhood.Text), similarity, dataModel);
			}
			if (radioButton_ThresholdUserNeighborhood.Checked) {
				return new ThresholdUserNeighborhood(Convert.ToDouble(textBox_threshold.Text, CultureInfo.InvariantCulture), similarity, dataModel);
			}
			throw new NotSupportedException();
		}


		public class UserBasedRecommenderBuilder : IRecommenderBuilder {

			EvaluatorForm f;

			public UserBasedRecommenderBuilder(EvaluatorForm form) {
				f = form;
			}

			public NReco.CF.Taste.Recommender.IRecommender BuildRecommender(IDataModel dataModel) {
				var similarity = f.GetUserSimilarity(dataModel);
				var neighborhood = f.GetNeighborhood(dataModel, similarity);
				if (dataModel is FileDataModel && ((FileDataModel)dataModel).GetLoadedDataModel() is GenericBooleanPrefDataModel )
					return new GenericBooleanPrefUserBasedRecommender(dataModel, neighborhood, similarity);
				return new GenericUserBasedRecommender(dataModel, neighborhood, similarity);
			}
		}

		public class ItemBasedRecommenderBuilder : IRecommenderBuilder {

			EvaluatorForm f;

			public ItemBasedRecommenderBuilder(EvaluatorForm form) {
				f = form;
			}

			public NReco.CF.Taste.Recommender.IRecommender BuildRecommender(IDataModel dataModel) {
				var similarity = f.GetItemSimilarity(dataModel);
				var candidateItemStrategy = f.GetCandidateItemsStrategy(dataModel, similarity);

				if (dataModel is FileDataModel && ((FileDataModel)dataModel).GetLoadedDataModel() is GenericBooleanPrefDataModel )
					return new GenericBooleanPrefItemBasedRecommender(dataModel, similarity, candidateItemStrategy,
						candidateItemStrategy as IMostSimilarItemsCandidateItemsStrategy);

				return new GenericItemBasedRecommender(dataModel, similarity, candidateItemStrategy,
					candidateItemStrategy as IMostSimilarItemsCandidateItemsStrategy);
			}
		}

		private void groupBox5_Enter(object sender, EventArgs e) {

		}

		void OnRecommenderChanged() {
			groupBox_Neighborhood.Enabled = radioButton_userBased.Checked;
			groupBox_CandidateItemsStrategy.Enabled = radioButton_itemBased.Checked;
			
			radioButton_SpearmanCorrelationSimilarity.Enabled = radioButton_userBased.Checked;
			if (!radioButton_SpearmanCorrelationSimilarity.Enabled && radioButton_SpearmanCorrelationSimilarity.Checked)
				radioButton_PearsonCorrelationSimilarity.Checked = true;
		}

		private void radioButton_userBased_CheckedChanged(object sender, EventArgs e) {
			OnRecommenderChanged();
		}

		private void radioButton_itemBased_CheckedChanged(object sender, EventArgs e) {
			OnRecommenderChanged();
		}

		private void buttonBrowseFile_Click(object sender, EventArgs e) {
			if (openFileDialog1.ShowDialog() == System.Windows.Forms.DialogResult.OK) {
				textBox_filePath.Text = openFileDialog1.FileName;
			}
			
		}

		private void label6_Click(object sender, EventArgs e) {

		}



    }
}
