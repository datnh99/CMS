﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

using NReco.CF.Taste.Model;
using NReco.CF.Taste.Impl.Model;
using NReco.CF.Taste.Impl.Recommender;
using NReco.CF.Taste.Impl.Similarity;
using System.Data.SQLite;

namespace NReco.Recommender.Examples.SqlDbSource {

	/// <summary>
	/// In this example dataset is taken from SQL database ('northwind' orders).
	/// </summary>
	class Program {

		static void Main(string[] args) {

			var ordersDataModel = LoadOrdersDataModel();

			// lets assume that we have a new user interted in some product
			var currentProductID = 57; // Product Name: Ravioli Angelo
			
			var modelWithCurrentUser = GetDataModelForNewUser(ordersDataModel, currentProductID);

			var similarity = new LogLikelihoodSimilarity(modelWithCurrentUser);
			
			// in this example, we have no preference values (scores)
			// to get correct results 'BooleanfPref' recommenders should be used

			var recommender = new GenericBooleanPrefItemBasedRecommender(modelWithCurrentUser, similarity);

			var recommendedItems = recommender.Recommend(PlusAnonymousUserDataModel.TEMP_USER_ID, 3, null);

			Console.WriteLine("Products similar to {0} ({1}):", currentProductID, GetProductName(currentProductID) );
			foreach (var ri in recommendedItems) {
				Console.WriteLine("\tProductID={0}: {1}", ri.GetItemID(), GetProductName(ri.GetItemID()));
			}
			Console.WriteLine("Press any key to continue...");
			Console.ReadKey();
		}

		/// <summary>
		/// Load data model by SQL SELECT query.
		/// </summary>
		static IDataModel LoadOrdersDataModel() {
			var dbConnection = System.Data.SQLite.SQLiteFactory.Instance.CreateConnection();
			dbConnection.ConnectionString = "Data Source="+Path.Combine( Directory.GetCurrentDirectory(), "northwind.db" );			

			var selectCmd = dbConnection.CreateCommand();
			selectCmd.CommandText = "select OrderID, ProductID from [Order Details]";
			
			var dataModelLoader = new DataModelSqlLoader(selectCmd, "OrderID", "ProductID");
			IDataModel dataModel = null;

			dbConnection.Open();
			try {
				dataModel = dataModelLoader.Load();
			} finally {
				dbConnection.Close();
			}
			return dataModel;
		}

		/// <summary>
		/// Wrap specified data model with 'PlusAnonymousUserDataModel' (adds new user and its preferences).
		/// </summary>
		static IDataModel GetDataModelForNewUser(IDataModel baseModel, params long[] preferredItems) {
			var plusAnonymModel = new PlusAnonymousUserDataModel(baseModel);
			var prefArr = new BooleanUserPreferenceArray(preferredItems.Length);
			prefArr.SetUserID(0, PlusAnonymousUserDataModel.TEMP_USER_ID);
			for (int i = 0; i < preferredItems.Length; i++) {
				prefArr.SetItemID(i, preferredItems[i]);
			}
			plusAnonymModel.SetTempPrefs(prefArr);
			return plusAnonymModel;
		}

		static string GetProductName(long productID) {
			var dbConnection = System.Data.SQLite.SQLiteFactory.Instance.CreateConnection();
			dbConnection.ConnectionString = "Data Source="+Path.Combine( Directory.GetCurrentDirectory(), "northwind.db" );			

			var selectCmd = dbConnection.CreateCommand();
			selectCmd.CommandText = "select ProductName from [Products] where ProductID="+productID;
			dbConnection.Open();
			try {
				var rdr = selectCmd.ExecuteReader();
				while (rdr.Read())
					return rdr["ProductName"].ToString();
			} finally {
				dbConnection.Close();
			}
			return null;
		}

	}
}
