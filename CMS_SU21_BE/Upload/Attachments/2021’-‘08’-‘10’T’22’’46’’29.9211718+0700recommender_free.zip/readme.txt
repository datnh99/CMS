NReco Recommender Library (EXAMPLES PACK)
-----------------------------------------
Recommender is a C# port of Apache Mahout "Taste" collaborative filtering engine (https://mahout.apache.org/users/algorithms/recommender-overview.html). 
Most namespaces, class names and public methods are aligned with C# naming conventions.

Links
-----
Website:             https://www.nrecosite.com/recommender_net.aspx
Source code (AGPL):  https://github.com/nreco/recommender 
Nuget:               https://www.nuget.org/packages/NReco.Recommender

Examples
--------
*** MovieLensMvc ***
How to configure user-based recommender making film recommendations (made by 100k MovieLens dataset http://grouplens.org/datasets/movielens/ ). 

*** SqlDbSource ***
Recommend products (item-to-item, without scores) by existing orders stored in SQL database ('northwind', SQLite).

*** Evaluator ***
Simple GUI utility (WinForms) that helps to evaluate dataset and find best similarity function and other recommendation engine options.

License
-------
NReco.Recommender free version is published under AGPL license.

Buying a commercial license is mandatory as soon as you develop commercial activities distributing the NReco Recommender
inside your product or deploying it on a network without disclosing the source code of your own applications under the AGPL license. 
These activities include:
- offering paid services to customers as an ASP
- making recommendations in the cloud or in a web application
- shipping NReco Recommender with a closed source product
