﻿namespace movierecommender.Models
{
    public class Movie
    {
        public int MovieID { get; set; }
        public string MovieName { get; set; }
    }    
}