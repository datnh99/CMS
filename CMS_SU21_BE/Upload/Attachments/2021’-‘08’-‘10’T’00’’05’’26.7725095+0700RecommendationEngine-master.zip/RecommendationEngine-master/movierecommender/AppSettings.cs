﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace movierecommender
{
    public class AppSettings
    {
        public string apikey { get; set; }
        public string uri { get; set; }
    }
}
